
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const multer = require('multer');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'public/uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});

const upload = multer({ storage: storage });

app.use(express.static('public'));

app.post('/upload-image', upload.single('image'), (req, res) => {
  io.emit('show-image', '/uploads/' + req.file.filename);
  res.sendStatus(200);
});

app.post('/upload-video', upload.single('video'), (req, res) => {
  io.emit('show-video', '/uploads/' + req.file.filename);
  res.sendStatus(200);
});

app.post('/show-text', express.urlencoded({ extended: true }), (req, res) => {
  io.emit('show-text', req.body.text);
  res.sendStatus(200);
});

app.post('/clear', (req, res) => {
  io.emit('clear-screen');
  res.sendStatus(200);
});

// WebRTC signaling events for screen sharing
io.on('connection', (socket) => {
  socket.on('offer', (offer) => {
    socket.broadcast.emit('offer', offer);
  });

  socket.on('answer', (answer) => {
    socket.broadcast.emit('answer', answer);
  });

  socket.on('ice-candidate', (candidate) => {
    socket.broadcast.emit('ice-candidate', candidate);
  });
});

server.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
});
